
export default function Dashboard(){
  return <div className="container">
    <h2>Dashboard</h2>
    <div className="card"><p>KPIs, quick actions and recent jobs will appear here.</p></div>
  </div>;
}
